package com.example.Model;

import com.example.Model.Item.Item;

import java.util.ArrayList;

public class Quest {
    private ArrayList<Item> GivenItems;
    private ArrayList<Item> TakenItems;
    public Quest() {
    }
}

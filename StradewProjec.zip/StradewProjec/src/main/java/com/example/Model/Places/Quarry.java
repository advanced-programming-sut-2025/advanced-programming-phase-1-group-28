package com.example.Model.Places;

public class Quarry extends Place {
    public Quarry(int x , int y) {
        X_Coordinate = x;
        Y_Coordinate = y;
    }
}

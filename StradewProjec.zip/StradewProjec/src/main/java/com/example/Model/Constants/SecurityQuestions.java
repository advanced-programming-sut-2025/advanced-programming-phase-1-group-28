package com.example.Model.Constants;

import java.util.ArrayList;

public class SecurityQuestions {
    public static ArrayList<String> Questions = new ArrayList<>();
    static {
        //Add our Questions
    }
}

package com.example.Model.Enums;

public enum Season {
    SPRING, SUMMER, FALL , WINTER;
}

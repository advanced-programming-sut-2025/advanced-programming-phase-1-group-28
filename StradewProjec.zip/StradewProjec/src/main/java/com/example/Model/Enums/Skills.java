package com.example.Model.Enums;

public enum Skills {
    Farming , Mining , Fishing , Foraging
}

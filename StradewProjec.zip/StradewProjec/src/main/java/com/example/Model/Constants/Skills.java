package com.example.Model.Constants;

import com.example.Model.Skill;

import java.util.ArrayList;

public class Skills {
    public static ArrayList<Skill> skills = new ArrayList<>();
    static {
        //Create Skills
    }

}

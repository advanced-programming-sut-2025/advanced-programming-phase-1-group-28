package com.example.Model.Tools;

import com.example.Model.Enums.Skills;

public class Seythe extends Tools{
    public Seythe() {
        name = "Seythe";
        count = 1;
        IsExist = true;
        EnergyCost = 2;
        Id = 6;
        skillRelated = Skills.Farming;
    }
}

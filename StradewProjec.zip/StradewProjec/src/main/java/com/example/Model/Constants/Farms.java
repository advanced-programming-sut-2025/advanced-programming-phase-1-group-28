package com.example.Model.Constants;

import com.example.Model.Places.Farm;

import java.util.ArrayList;

public class Farms {
    public static ArrayList<Farm> farms= new ArrayList();
    static {
//        //Creating FirstFarm
//        Farm newFarm1 = new Farm();
//        //Creating SecondFarm
//        Farm newFarm2 = new Farm();
//        //Creating ThirdFarm
//        Farm newFarm3 = new Farm();
    }
}

package com.example.Model;

public class Weather {
    private String Name;

    public Weather(String name) {
        Name = name;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }
}

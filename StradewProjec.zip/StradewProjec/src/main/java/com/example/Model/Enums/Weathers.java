package com.example.Model.Enums;

public enum Weathers {
    SUNNY , RAIN , STORM , SNOW
}



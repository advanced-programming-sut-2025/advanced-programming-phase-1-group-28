package com.example.Model.Enums;

public enum Qualities {
    Normal ,
}

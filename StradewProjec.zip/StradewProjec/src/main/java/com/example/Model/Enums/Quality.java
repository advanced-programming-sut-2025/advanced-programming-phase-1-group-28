package com.example.Model.Enums;

public enum Quality {
    Regular , Silver , Gold , Iridium
}

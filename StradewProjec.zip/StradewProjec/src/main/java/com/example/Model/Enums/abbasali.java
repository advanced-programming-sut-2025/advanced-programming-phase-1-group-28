package com.example.Model.Enums;

public enum abbasali {
    abbas , asghar;
}

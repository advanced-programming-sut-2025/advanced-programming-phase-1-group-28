package com.example.Model.Enums;

public enum Fertilizer {

}

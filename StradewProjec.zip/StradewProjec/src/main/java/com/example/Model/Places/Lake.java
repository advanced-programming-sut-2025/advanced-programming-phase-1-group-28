package com.example.Model.Places;

public class Lake extends Place {
    public Lake(int x_Cordinate , int y_Cordinate) {
        X_Coordinate = x_Cordinate;
        Y_Coordinate = y_Cordinate;
    }

}

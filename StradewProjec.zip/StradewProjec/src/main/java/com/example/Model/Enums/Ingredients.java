package com.example.Model.Enums;

public enum Ingredients {
    CowMilk,
    GoatMilk,
    SheepCotton,
    Hay,
    Sugar,
    Wheat_Flour,
    Rice,
    Oil,
    Vinegar,
    Basic_Retaining_Oil,
    Quality_Retaining_Oil,
    Deluxe_Retaining_Oil,
    Egg,
    LargeEgg,
    DuckEgg,
    DuckFeather,
    RabbitWool,
    RabbitLeg,
    DinosaurEgg,
    LargeCowMilk,
    LargeGoatMilk,
    Truffle;
}
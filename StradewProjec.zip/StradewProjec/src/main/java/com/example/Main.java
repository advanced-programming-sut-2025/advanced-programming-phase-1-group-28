package com.example;
import com.example.Model.Enums.MenuName;
import com.example.Model.Tools.Pepolee;
import com.example.View.AppInputCommand;
import com.google.gson.Gson;
import java.io.FileWriter;
import java.io.IOException;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        AppInputCommand InputObject = new AppInputCommand();
        while(true) {
            if(!InputObject.InputCommands())
            {
                break;
            }
        }
    }
}
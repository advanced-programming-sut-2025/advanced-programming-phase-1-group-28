package com.example.Controller.MainMenuController;

public class ShowController {
    public boolean IsToolExist(String ToolName)
    {
        return false;
    }
    public boolean IsItTool()
    {
        return false;
    }
    public boolean IsAnythingHere(int x , int y)
    {
        return true;
    }
}

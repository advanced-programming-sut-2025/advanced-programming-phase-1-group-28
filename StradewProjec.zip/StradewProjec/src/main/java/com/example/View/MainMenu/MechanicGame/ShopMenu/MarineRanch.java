package com.example.View.MainMenu.MechanicGame.ShopMenu;

public class MarineRanch {
    public void BuyPet(String PetType , String PetName)
    {

    }
}
